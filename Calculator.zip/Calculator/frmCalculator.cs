﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/****************************************
 * Kelvin Boapeah,
 * Dr. Kevin McdDonnell,
 * Advanced programming 
 * October 17th, 2013.
 * 
 * Important: The numeric keypad has being assigned to the digits, and the operators as well. "Alt + C"  or Esc will clear the textbox.
 * Entering an expression such as "2 + -2" will evaluate to 0 which is correct, but the textbox might show "2 +" first, then clear this expression, then "-2" next.
 ****************************************/

namespace Calculator
{
    public partial class frmCalculator : Form
    {
        public frmCalculator()
        {
            InitializeComponent();
            btnCalculate.Focus();
        }

        bool b = false, tf = false; //flag variable
        Queue<decimal> num = new Queue<decimal>(50);//initial capacity
        decimal temp1;
        Queue<char> ops = new Queue<char>(50); //initial capacity
        int lowerboundindex = 0, operators = 0, numbers = 0;

        /// <summary>
        ///  Clears the screen when the Clear button is clicked
        /// </summary>
        /// <param name="sender">The object that generated the event</param>
        /// <param name="e">Information about the event</param>
        private void btnClear_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            txtScreen.Text = "0";
            txtScreen2.Text = ""; //answer screen
            operators = 0;
            temp1 = 0;
            numbers = 0;
            lowerboundindex = 0;
            num.Clear();
            ops.Clear();
            b = false;
            tf = false;
        }

        /// <summary>
        /// Event-handler for the zero button. Appends 0 to the expression
        /// </summary>
        /// <param name="sender">The object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnZero_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true) // first, check and see if this calculation is following another calculation, by usin the flag variable
                txtScreen2.Text = "";

            if (txtScreen.Text == "0") { }

            else if (txtScreen.Text != "0")
                txtScreen.Text += "0";
            // txtXYRadius.ScrollToCaret();    // move the textbox scroll bar down to the line we just wrote


        }

        /// <summary>
        /// Event-handler for the one button. Appends 1 to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnOne_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";

            if (txtScreen.Text == "0")
                txtScreen.Text = "1";
         
            else
                txtScreen.Text += "1";
        }

        /// <summary>
        /// Event-handler for the two button. Appends 2 to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnTwo_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";

            if (txtScreen.Text == "0")
                txtScreen.Text = "2";

            else
                txtScreen.Text += "2";
        }

        /// <summary>
        /// Event-handler for the three button. Appends 3 to the expression
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnThree_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";

            if (txtScreen.Text == "0")
                txtScreen.Text = "3";
            
            else
                txtScreen.Text += "3";
        }

        /// <summary>
        /// Event-handler for the four button. Appends 4 to the expression
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Contains information about the event</param>
        private void btnFour_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";
            
            if (txtScreen.Text == "0")
                txtScreen.Text = "4";

            else
                txtScreen.Text += "4";
        }

        /// <summary>
        /// Event-handler for the four button. Appends 4 to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnFive_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";
            
            if (txtScreen.Text == "0")
                txtScreen.Text = "5";
          
            else
                txtScreen.Text += "5";
        }

        /// <summary>
        /// Event-handler for the six button. Appends 6 to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnSix_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";
            
            if (txtScreen.Text == "0")
                txtScreen.Text = "6";

            else
                txtScreen.Text += "6";
        }

        /// <summary>
        /// Event-handler for the seven button. Appends 7 to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnSeven_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";
            
            if (txtScreen.Text == "0")
                txtScreen.Text = "7";
        
            else
                txtScreen.Text += "7";
        }

        /// <summary>
        /// Event-handler for the eight button. Appends 8 to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnEight_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";
            
            if (txtScreen.Text == "0")
                txtScreen.Text = "8";
          
            else
                txtScreen.Text += "8";
        }

        /// <summary>
        /// This method is the event-handler for the "9" button. It appends a 9 to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnNine_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";
            
            if (txtScreen.Text == "0")//at first entry
                txtScreen.Text = "9";
          
            else
                txtScreen.Text += "9"; //otherwise append
        }

        /// <summary>
        /// This method goes through the expression, and checks if there is a period (.) in the current number. If an operator is met before a 
        /// period sign, the method returns true. If a period is met before an operator, the method returns false
        /// </summary>
        /// <param name="sender"> the object that generated the event</param>
        /// <param name="e"> information about the event</param>
        private void btnPeriod_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (b == true)
                txtScreen2.Text = "";

            if (txtScreen.Text == "0") //can subtract from zero
                txtScreen.Text += '.';
                
            else if (checkForPeriod(txtScreen.Text) == true)
            {
                txtScreen.Text += '.';
                //MessageBox.Show("result: " + checkForPeriod(txtScreen.Text), "Note");
            }

           else if (checkForPeriod(txtScreen.Text) == false) {} //do nothing

            else
                txtScreen.Text += '.';
            //write a method that effciently goes thru the string to determine if there is a period
        }

        /// <summary>
        /// This method is the event-handler for the addition button. It appends a plus sign to the expression
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Contains information about the event</param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            char chars = txtScreen.Text[txtScreen.Text.Length - 1];

            if (txtScreen.Text == "0")
                txtScreen.Text += "+"; //appends
          
            else if (chars == '+') { } // do nothing

            else if (chars == '-' || chars == '×' || chars == '÷')
            {
                txtScreen.Text = txtScreen.Text.Remove(txtScreen.Text.Length-1,1); //note this
                txtScreen.Text += "+";
            }

            else
                txtScreen.Text += '+';
        }

        /// <summary>
        /// This method is the event-handler for the subtraction button. It appends a minus sign to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnSubtract_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            char chars = txtScreen.Text[txtScreen.Text.Length - 1];

            if (txtScreen.Text == "0") //can subtract from zero
                txtScreen.Text += '-';

            else if (chars == '-' ) { } //do nothing

            else if (chars == '+' || chars == '×' || chars == '÷')
            {
                txtScreen.Text = txtScreen.Text.Remove(txtScreen.Text.Length - 1, 1);
                txtScreen.Text += '-';
            }

            else
                txtScreen.Text += '-';
        }

        /// <summary>
        /// This method is the event-handler for the multiplication button. It appends a times sign to the expression
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnMultiply_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            char chars = txtScreen.Text[txtScreen.Text.Length - 1];

            if (txtScreen.Text == "0") // can multiply by zero
                txtScreen.Text += '×';

            else if (chars == '×' ) { } // do nothing

            else if (chars == '-' || chars == '+' || chars == '÷')
            {
                txtScreen.Text = txtScreen.Text.Remove(txtScreen.Text.Length - 1, 1);
                txtScreen.Text += '×';
            }

            else
                txtScreen.Text += '×';
        }

        /// <summary>
        /// This method is the event-handler for the divide button. It appends the division sign to the string
        /// </summary>
        /// <param name="sender">The object that generated the event</param>
        /// <param name="e">Contains information about the event that is generated</param>
        private void btnDivide_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            char chars = txtScreen.Text[txtScreen.Text.Length - 1]; //note this. Method scope

            if (txtScreen.Text == "0") // can divide a number by zero
                txtScreen.Text += '÷';

            else if (chars == '÷') { } // do nothing

            else if (chars == '-' || chars == '+' || chars == '×')
            {
                txtScreen.Text = txtScreen.Text.Remove(txtScreen.Text.Length - 1, 1);
                txtScreen.Text += '÷';
            }

            else
                txtScreen.Text += '÷';
        }
        
        /// <summary>
        /// This method check whether a period was entered for a given number
        /// </summary>
        /// <param name="str">The user entry</param>
        /// <returns>true, if there are no period entered for that given number, and false if otherwise</returns>
        private bool checkForPeriod(string str)
        { // method scope
            btnCalculate.Focus();
            bool tf = true;

            for (int i = str.Length - 1; i > -1; i--) //works backward to find a period sign or an operator
            {
                if (txtScreen.Text[i] == '.')
                {
                    tf = false;
                    i = 0; // break out of for loop
                }

                else if (txtScreen.Text[i] == '+' | txtScreen.Text[i] == '-' | txtScreen.Text[i] == '×' | txtScreen.Text[i] == '÷')
                {
                    tf = true;
                    i = 0; // break out of for loop
                }
            }
            return tf;
        }

        /// <summary>
        /// This method is the event-handler of the calculate button.
        /// </summary>
        /// <param name="sender">The object that generated the event</param>
        /// <param name="e">Contains information about the event</param>
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                  if (txtScreen.Text[txtScreen.Text.Length - 1] >= '0' && tf == false) //change
                  {
                      num.Enqueue(createsNumber(txtScreen.Text.Length)); //used to increase the length of the text by 1, thereby createsNumber method can work correctly
                      numbers++;
                      evvaluAte();
                      /////////////////////After calculation is done/////////////////////////////////
                      txtScreen.Text = "0";
                      b = true; //flag varable
                      num.Clear(); //clears the num queue after each calculation done using the enter button
                      operators = 0;
                      temp1 = 0;
                      numbers = 0;
                      lowerboundindex = 0;
                      ops.Clear();
                  }

                  else if (txtScreen.Text[txtScreen.Text.Length - 1] >= '0' && tf == true)
                  {
                      decimal temp5;
                      temp5 = createsNumber(txtScreen.Text.Length);
                      temp5 = temp5 * -1; //multiply the number by negative one to make it negative
                      num.Enqueue(temp5);
                      numbers++;
                      evvaluAte();
                      /////////////////////After calculation is done/////////////////////////////////
                      txtScreen.Text = "0";
                      b = true; //flag varable
                      num.Clear(); //clears the num queue after each calculation done using the enter button
                      operators = 0;
                      temp1 = 0;
                      numbers = 0;
                      lowerboundindex = 0;
                      ops.Clear();
                      tf = false;
                  }
                
               
            }
            catch (Exception problem)
            {
                MessageBox.Show(problem.Message + "\n\n" +
                    problem.GetType().ToString() + "\n" +
                    problem.StackTrace, "Exception");
                b = true; // has there being a calculation?
            }
        }  

/// <summary>
 /// This method takes a substring from the string in the text box, and converts it to a number.
/// </summary>
/// <param name="upperboundindex">The index where the operator is read</param>
/// <returns>The substring converted to a decimal number</returns>
        private decimal createsNumber(int upperboundindex)
        {
            decimal num;
            int x;
            string str = "";

            for (x = lowerboundindex; x < upperboundindex; x++)
            { //In the event the user entered a period...
                str += Convert.ToString(txtScreen.Text[x]); //character to string
            }
            Decimal.TryParse(str, out num); //string to decimal
            lowerboundindex = upperboundindex + 1;
            return num;
        }

        /// <summary>
        /// This method takes the operator and stores it in an queue of operators
        /// </summary>
        /// <param name="counter2">The location where the operator is found</param>
        private void operatorEntry(char counter2)
        {
            ops.Enqueue(counter2);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtScreen_TextChanged(object sender, EventArgs e)
        {   
            if (txtScreen.Text[txtScreen.Text.Length - 1] == '+' || txtScreen.Text[txtScreen.Text.Length - 1] == '-' || txtScreen.Text[txtScreen.Text.Length - 1] == '×' || txtScreen.Text[txtScreen.Text.Length - 1] == '÷')
            {
                operatorEntry(txtScreen.Text[txtScreen.Text.Length - 1]);
                operators++;

                temp1 = createsNumber(txtScreen.Text.Length - 1); //returns with the decimal number

                if (tf == true)
                {
                    temp1 = temp1 * -1;
                    tf = false;
                }

                num.Enqueue(temp1); //number entered into the queue
                numbers++;

                if(operators >= 2)
                    evvaluAte();
            }
        }

        /// <summary>
        /// This method does the calculation 
        /// </summary>
        private void evvaluAte()
        {
            decimal temp3 = 0, temp4 = 0;
            switch(ops.Dequeue())
            {
                    case '+': //addition 
                        if (txtScreen2.Text == "")
                        {
                            txtScreen2.Text = (num.Dequeue() + num.Dequeue()).ToString();
                        }

                        else
                        {
                            txtScreen2.Text = ((Decimal.Parse(txtScreen2.Text)) + num.Dequeue()).ToString();
                        }
                        break;

                    case '-': //subtraction
                        if (txtScreen2.Text == "")
                        {
                           txtScreen2.Text = (num.Dequeue() - num.Dequeue()).ToString(); //issue
                         }
                        
                        else
                        {
                           txtScreen2.Text = ((Decimal.Parse(txtScreen2.Text)) - num.Dequeue()).ToString();
            
                        }
                        break;

                    case '×': //multiplication
                        if (txtScreen2.Text == "")
                        {
                           txtScreen2.Text = (num.Dequeue() * num.Dequeue()).ToString();
                        }
                        
                        else
                        {
                           txtScreen2.Text = ((Decimal.Parse(txtScreen2.Text)) * num.Dequeue()).ToString();
                        }
                        break;

                    case '÷': //division
                        
                        if (num.Count >= 2)
                        {
                           temp3 = num.Dequeue();
                           temp4 = num.Dequeue();
                        }
                        
                        if (temp4 == 0)
                            MessageBox.Show("cannot divide by zero '0'", "Warning");
                        
                        else if (temp4 != 0 && txtScreen2.Text == "")
                        {
                           txtScreen2.Text = (temp3 / temp4).ToString();
                           
                         }
                        
                        else
                        {
                           txtScreen2.Text = ((Decimal.Parse(txtScreen2.Text)) / temp3).ToString();
                        }
                         break;
                }
            }

        /// <summary>
        /// This method is the event-handler for the sign-change button. It simply changes the sign of a number
        /// </summary>
        /// <param name="sender">The control that generated the method</param>
        /// <param name="e">Contains information about the event </param>
        private void btnSign_Click(object sender, EventArgs e)
        {
            btnCalculate.Focus();
            if (tf == false)//txtScreen.Text[0] == '0'
            {
                txtScreen.Text = "~";
                lowerboundindex = 1;
                tf = true;

            }

            if (txtScreen.Text[txtScreen.Text.Length - 1] != '~')
            {
                lowerboundindex++; //moves the lower index up by 1
                txtScreen.Text += '~';
                tf = true;
            }
        }
        }
    }

