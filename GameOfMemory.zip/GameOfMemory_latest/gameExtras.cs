﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameOfMemory
{
    /**************************************
 * Kelvin Boapeah,
 * Dr. Kevin McDonnell,
 * Advanced Programming I,
 * December 17th 2013
 * **************************************/

    class gameExtras
    {
        //members
        static gameCard[] arrayCards = new gameCard[20];

        static int[] assign = new int[20];
        static Random rand = new Random();
        static Random rand2 = new Random();

        static int i = 1;

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static bool initializeArray()
        {
            for (int x = 0; x < 20; x++)
            {
                assign[x] = i;

                if (i == 10)
                    i = 0;
                i++;
            }
            ///////////////////////////////////////////////////////////////////
            return true;
        }

        /// <summary>
        /// Randomly assigns images to the cards. There must be two of each image on the table
        /// </summary>
        /// <returns>True, if the images were successfully assigned to all cards. False if otherwise</returns>
        public static void ImageRandomizer()
        {
            int num, num2, temp;

            for (int hh = 0; hh < 100; hh++)
            {
                num = rand.Next(0, 20);
                num2 = rand.Next(0, 20);
                ///swap
                temp = assign[num];
                assign[num] = assign[num2];
                assign[num2] = temp;
            }

            for (int y = 0; y < arrayCards.Length; y++)
            {
                arrayCards[y].setUniqueCardImg(new Bitmap(@"..\..\Properties\playing_cards\" + assign[y] + ".jpg"));
                arrayCards[y].setPicId(assign[y]);

            }
        }

        /// <summary>
        /// Compare the two images to see if they match
        /// </summary>
        /// <returns>returns true if the comparison matched. False if otherwise</returns>
        public static bool twoImgComparer(PictureBox cardnum1, PictureBox cardnum2){
            bool tf = false;
            int I = gameCard.getObject(cardnum1).getPicId();
            int J = gameCard.getObject(cardnum2).getPicId();

            if ((I == J)){
                MessageBox.Show("Remove cards"); ///
                tf = true;
            }

            return tf;
        }


        /// <summary>
        /// Adds a card object to a list of card objects
        /// </summary>
        /// <param name="cardNum">the card object to be added</param>
        /// <param name="T">the index where to insert the card object</param>
        /// <returns>true if the card was inserted</returns>
        public static bool addCardToList(gameCard cardNum, int T)
        { //integer locations must not overlap!
            arrayCards[T] = cardNum;
            return true;
        }

        /// <summary>
        /// Returns a list of card objects
        /// </summary>
        /// <returns>the list of card objects</returns>
        public static gameCard[] returnListOfCards()
        { // returns all an array of cards
            return arrayCards;
        }

        /// <summary>
        /// The method returns a card from the list of card objects, given the index where the card is located
        /// </summary>
        /// <param name="T">the index where the card is located</param>
        /// <returns>the card retrieved from the list</returns>
        public gameCard returnCardFromList(int T)
        { // returns a single card
            return arrayCards[T];
        }

        /// <summary>
        /// Given partial information (pictureBox), returns the true or false variable for the card object
        /// </summary>
        /// <param name="picBox">the picture box for the card object</param>
        /// <returns>a boolean</returns>
        public static bool returnCardBoolean(PictureBox picBox)
        { //given the picbox control, the method returns true if it was moved, and false if otherwise
            bool u = true;
            for (int e = 0; e < arrayCards.Length; e++)
            {
                if (arrayCards[e].returnPictureBox() != null)
                {
                    if (arrayCards[e].returnPictureBox() == picBox && arrayCards[e].returnCardBoolean() == false) //for each objec, return its picturebox, then compare
                        u = false;
                    //e = cardObj.Length;
                }
            }

            return u;
        }

        /// <summary>
        /// Given partial information, this method sets the boolean variable of a card object
        /// </summary>
        /// <param name="box">a pictureBox which is part of the card object</param>
        /// <param name="b">the new boolean to set to</param>
        /// <returns>true if the boolean was set, false if otherwise</returns>
        public static bool setCardBoolean(PictureBox box, bool b) //true
        {
            bool h = false;
            for (int d = 0; d < arrayCards.Length; d++)
            {
                if (arrayCards[d].returnPictureBox() != null)
                {
                    if (arrayCards[d].returnPictureBox() == box && arrayCards[d].returnCardBoolean() == false)
                    {
                        arrayCards[d].setCardBoolean(b); //set the boolean to true
                        h = true;
                    }
                    //d = cardObj.Length;

                }
            }

            return h;
        }

        /// <summary>
        /// This method gets the code for the image from the specified path to the image's location in windows explorer
        /// </summary>
        /// <param name="str">The path to the image</param>
        /// <returns>the code used to locate the image</returns>
        public static Int16 getCodeFrmString(string str)
        {
            string str2 = "";
            bool g = false;
            for (int x = str.Length - 1; x > 0; x--)
            {
                if (g == true && str[x] != '.' && str[x] != '\\')
                {
                    str2 = str[x] + str2;
                }
                if (str[x] == '.')
                    g = true;

                if (str[x] == '\\')
                    x = 0;// break out of loop               
            }
            MessageBox.Show("Note: " + Convert.ToInt16(str2), "Note");
            return Convert.ToInt16(str2);
        }
    }
}
