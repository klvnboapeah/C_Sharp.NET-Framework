﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameOfMemory
{
/**************************************
 * Kelvin Boapeah,
 * Dr. Kevin McDonnell,
 * Advanced Programming I,
 * December 17th 2013
 * **************************************/
    static class AnimationClass
    {
        //member variables//
        static int[] Yvalues = new int[20];
        static int callcounter = 0, RemoveCounter = 0;
       


        /// <summary>
        /// this method animates a waiting period, which is about 1 second. Note: this method was not used
        /// </summary>
        /// <returns>true, when the time has elasped</returns>
        public static bool animateWait()
        {
            for (Int64 y = 2000; y > 0; y--) //9000, 8000, 7000, 6000, 5000, 4000, 3000
            {
                for (Int64 yy = 50000; yy > 0; yy--) { } //90000, 70000
            }
            return true;
        }

        /// <summary>
        /// given the picturebox of a card object, this method finds the card object, and animates the card being removed
        /// </summary>
        /// <param name="cardNum">the picture box of the card image</param>
        public static bool animateAnimateur(PictureBox cardAnimateur)
        {
            int tempX = cardAnimateur.Location.X;
            int tempY = cardAnimateur.Location.Y;

            for (Int64 y = 20000; y > 0; y--) //50000, 30000
            {
                if (cardAnimateur.Location.X <= Screen.PrimaryScreen.WorkingArea.Width - 30)
                {
                    cardAnimateur.Location = new Point(cardAnimateur.Location.X + 1, cardAnimateur.Location.Y); //+1
                    cardAnimateur.Refresh();
                }

                if (cardAnimateur.Location.X > (Screen.PrimaryScreen.WorkingArea.Width - 30))
                {
                    y = 0;
                }
            }
            cardAnimateur.Location = new Point(tempX, tempY);
            return true;
        }

        /// <summary>
        /// given the current image of two identical cards, this method animates the cards being removed from the table
        /// </summary>
        /// <param name="cardNum1">card 1</param>
        /// <param name="cardNum2"> card 2</param>
        public static void animateCardRemoval(Image cardNum1, Image cardNum2)
        {
            PictureBox tempPcB = null, tempPcB2 = null;
            gameCard[] gg = gameExtras.returnListOfCards();
            ////////////////////////////////SEARCHING FOR THE PICTUREBOX THAT HAS AN IMAGE THAT MATCHES OUR IMAGE/////////////////////////////////////////////////////////////////////////////// 
            callcounter++;
            for (int qq = 0; qq < gg.Length; qq++)
            {

                if (gg[qq].returnUniqueCardImg() == cardNum1)
                {
                    tempPcB = gg[qq].returnPictureBox();
                    qq = gg.Length; //break out of the for-loop
                }
            }
            /////////////////////////////////                   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            for (int qq = 0; qq < gg.Length; qq++)
            {
                if (gg[qq].returnUniqueCardImg() == cardNum2)
                {
                    tempPcB2 = gg[qq].returnPictureBox();
                    qq = gg.Length; //break out of the for-loop
                }
            }
            ////////////////////////////////////////////////////////BEGINS THE ANIMATION////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //if (callcounter == 2)
            //{
            //tempX1 = tempPcB.Location.X;
            //tempY1 = tempPcB.Location.Y; //save the initial location of the picture 
            //tempX2 = tempPcB2.Location.X;
            //tempY2 = tempPcB2.Location.Y; //save the initial location of the picture 
            ///////////////////////////////////////////////////////////////////////////////////////////////////
            for (Int64 y = 50000; y > 0; y--)
            {
                if (tempPcB.Location.X <= Screen.PrimaryScreen.WorkingArea.Width - 30)
                {
                    tempPcB.Location = new Point(tempPcB.Location.X + 1, tempPcB.Location.Y); //+1
                    tempPcB.Refresh();
                }

                if (tempPcB.Location.X > (Screen.PrimaryScreen.WorkingArea.Width - 30))
                {
                    y = 0;
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            for (Int64 y = 50000; y > 0; y--)
            {
                if (tempPcB2.Location.X <= Screen.PrimaryScreen.WorkingArea.Width - 30)
                {
                    tempPcB2.Location = new Point(tempPcB2.Location.X + 1, tempPcB2.Location.Y); //+1
                    tempPcB2.Refresh();
                }

                if (tempPcB2.Location.X > (Screen.PrimaryScreen.WorkingArea.Width - 30))
                {
                    y = 0;
                }
                //}   
            }

            if (callcounter == 2) //reset the call counter after the second call
                callcounter = 0;
        }

        /// <summary>
        /// This method creates the card removal animation
        /// </summary>
        /// <param name="cardNum">partial information on the card to remove from the table</param>
        /// <param name="TT">an index to store the initial y-axis of the card</param>
        public static bool animateCardRemoval(PictureBox cardNum){

            if (gameCard.getObject(cardNum).returnCardBoolean() == true)
                MessageBox.Show("This card cannot be moved\n it is not a valid card");
            ///////////////////////////////////////////////////////////////////////////////////////////////////
            if (gameCard.getObject(cardNum).returnCardBoolean() == false)
            {///check before moving the card
                for (Int64 y = 50000; y > 0; y--) //5000000
                {
                    if (cardNum.Location.X <= Screen.PrimaryScreen.WorkingArea.Width - 30)
                    { //x 0.75
                        cardNum.Location = new Point(cardNum.Location.X + 1, cardNum.Location.Y); //+1
                        cardNum.Refresh();
                    }

                    if (cardNum.Location.X > (Screen.PrimaryScreen.WorkingArea.Width - 30))
                    { //- add
                        y = 0;
                        // add += 30; //initialize this when the booleans are all true
                    }
                }
            }

            gameCard.getObject(cardNum).setCardBoolean(true);///checker
            cardNum.Enabled = false;
            RemoveCounter++;

            //Note this//
            if (RemoveCounter == 18)
            { //we have already moved 18 cards, hence, flip the rest
                gameCard[] finalschecker = gameExtras.returnListOfCards();
    
                foreach (gameCard g in finalschecker)
                {
                    if(g.returnCardBoolean() == false)
                    {
                        //card1.Image = gameCard.returnUniqueCardImg(card1);
                        g.returnPictureBox().Image = gameCard.returnUniqueCardImg(g.returnPictureBox());
                        
                    }

                }
                AnimationClass.animateWait();
                return true;
            }

            return false;
        }

        static int skipper = 0;  //skip the image that was read before

        /// <summary>
        /// Given the current image of the card, this method animates the card being removed from the table
        /// </summary>
        /// <param name="src">the current image</param>
        public static void animateCardRemoval(Image src)
        {
            PictureBox tempPcB = null;//////////////////
            gameCard[] gg = gameExtras.returnListOfCards();
            ////////////////////////////////SEARCHING FOR THE PICTUREBOX THAT HAS AN IMAGE THAT MATCHES OUR IMAGE/////////////////////////////////////////////////////////////////////////////// 
            //        callcounter++;
            for (int qq = 0; qq < gg.Length; qq++)
            {

                if (qq != skipper && gg[qq].returnUniqueCardImg() == src)
                {
                    tempPcB = gg[qq].returnPictureBox();
                    qq = gg.Length; //break out of the for-loop
                    //skipper = qq;
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////////////////////
            try
            {
                for (Int64 y = 50000; y > 0; y--) //5000000, 50000, 
                {
                    if (tempPcB.Location.X <= Screen.PrimaryScreen.WorkingArea.Width - 30)
                    { //x 0.75
                        tempPcB.Location = new Point(tempPcB.Location.X + 1, tempPcB.Location.Y);
                        tempPcB.Refresh();
                    }

                    if (tempPcB.Location.X > (Screen.PrimaryScreen.WorkingArea.Width - 30))
                    { //- add
                        y = 0;
                        // add += 30; //initialize this when the booleans are all true
                    }
                }
            }
            catch (NullReferenceException problem)
            {
                MessageBox.Show(problem.Message, "Exception");
            }
        }
    }
}
