﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace GameOfMemory
{
    /**************************************
 * Kelvin Boapeah,
 * Dr. Kevin McDonnell,
 * Advanced Programming I,
 * December 17th 2013
 * **************************************/
    public partial class frmGOM2 : Form
    {
        public frmGOM2(bool T)
        {
            if (T == false)
            {
                InitializeComponent();                                  //randomly assign images                                        
                gameCard OneCard = new gameCard(card1, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -1, card1.Location.X, card1.Location.Y); // 
                gameExtras.addCardToList(OneCard, 0); //add object to a list of objects
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard TwoCard = new gameCard(card2, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -2, card2.Location.X, card2.Location.Y);
                gameExtras.addCardToList(TwoCard, 1); //add object to a list of objects
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard ThreeCard = new gameCard(card3, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -3, card3.Location.X, card3.Location.Y);
                gameExtras.addCardToList(ThreeCard, 2); //add object to a list of objects
                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard FourCard = new gameCard(card4, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -4, card4.Location.X, card4.Location.Y);
                gameExtras.addCardToList(FourCard, 3); //add object to a list of objects
                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard FiveCard = new gameCard(card5, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -5, card5.Location.X, card5.Location.Y);
                gameExtras.addCardToList(FiveCard, 4); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard SixCard = new gameCard(card6, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -6, card6.Location.X, card6.Location.Y);
                gameExtras.addCardToList(SixCard, 5); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard SevenCard = new gameCard(card7, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -7, card7.Location.X, card7.Location.Y);
                gameExtras.addCardToList(SevenCard, 6); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard EightCard = new gameCard(card8, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -8, card8.Location.X, card8.Location.Y);
                gameExtras.addCardToList(EightCard, 7); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard NineCard = new gameCard(card9, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -9, card9.Location.X, card9.Location.Y);
                gameExtras.addCardToList(NineCard, 8); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard TenCard = new gameCard(card10, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -10, card10.Location.X, card10.Location.Y);
                gameExtras.addCardToList(TenCard, 9); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard ElevenCard = new gameCard(card11, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -11, card11.Location.X, card11.Location.Y);
                gameExtras.addCardToList(ElevenCard, 10); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard TwelveCard = new gameCard(card12, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -12, card12.Location.X, card12.Location.Y);
                gameExtras.addCardToList(TwelveCard, 11); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard ThirteenCard = new gameCard(card13, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -13, card13.Location.X, card13.Location.Y);
                gameExtras.addCardToList(ThirteenCard, 12); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard FourteenCard = new gameCard(card14, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -14, card14.Location.X, card14.Location.Y);
                gameExtras.addCardToList(FourteenCard, 13); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard FifteenCard = new gameCard(card15, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -15, card15.Location.X, card15.Location.Y);
                gameExtras.addCardToList(FifteenCard, 14); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard SixteenCard = new gameCard(card16, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -16, card16.Location.X, card16.Location.Y);
                gameExtras.addCardToList(SixteenCard, 15); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard SeventeenCard = new gameCard(card17, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -17, card17.Location.X, card17.Location.Y);
                gameExtras.addCardToList(SeventeenCard, 16); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard EighteenCard = new gameCard(card18, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -18, card18.Location.X, card18.Location.Y);
                gameExtras.addCardToList(EighteenCard, 17); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard NinteenCard = new gameCard(card19, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -19, card19.Location.X, card19.Location.Y);
                gameExtras.addCardToList(NinteenCard, 18); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard TwentyCard = new gameCard(card20, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -20, card20.Location.X, card20.Location.Y);
                gameExtras.addCardToList(TwentyCard, 19); //add object to a list of objects
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameExtras.initializeArray();
                gameExtras.ImageRandomizer(); //randomly assign the unique image
            }


            if (T == true)
            {
                InitializeComponent();                                  //randomly assign images                                        
                gameCard OneCard = new gameCard(card1, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -1, card1.Location.X, card1.Location.Y); // 
                gameExtras.addCardToList(OneCard, 0); //add object to a list of objects
                card1.Enabled = true;
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard TwoCard = new gameCard(card2, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -2, card2.Location.X, card2.Location.Y);
                gameExtras.addCardToList(TwoCard, 1); //add object to a list of objects
                card2.Enabled = true;
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard ThreeCard = new gameCard(card3, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -3, card3.Location.X, card3.Location.Y);
                gameExtras.addCardToList(ThreeCard, 2); //add object to a list of objects
                card3.Enabled = true;
                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard FourCard = new gameCard(card4, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -4, card4.Location.X, card4.Location.Y);
                gameExtras.addCardToList(FourCard, 3); //add object to a list of objects
                card4.Enabled = true;
                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard FiveCard = new gameCard(card5, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -5, card5.Location.X, card5.Location.Y);
                gameExtras.addCardToList(FiveCard, 4); //add object to a list of objects
                card5.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard SixCard = new gameCard(card6, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -6, card6.Location.X, card6.Location.Y);
                gameExtras.addCardToList(SixCard, 5); //add object to a list of objects
                card6.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard SevenCard = new gameCard(card7, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -7, card7.Location.X, card7.Location.Y);
                gameExtras.addCardToList(SevenCard, 6); //add object to a list of objects
                card7.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard EightCard = new gameCard(card8, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -8, card8.Location.X, card8.Location.Y);
                gameExtras.addCardToList(EightCard, 7); //add object to a list of objects
                card8.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard NineCard = new gameCard(card9, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -9, card9.Location.X, card9.Location.Y);
                gameExtras.addCardToList(NineCard, 8); //add object to a list of objects
                card9.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard TenCard = new gameCard(card10, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -10, card10.Location.X, card10.Location.Y);
                gameExtras.addCardToList(TenCard, 9); //add object to a list of objects
                card10.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard ElevenCard = new gameCard(card11, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -11, card11.Location.X, card11.Location.Y);
                gameExtras.addCardToList(ElevenCard, 10); //add object to a list of objects
                card11.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard TwelveCard = new gameCard(card12, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -12, card12.Location.X, card12.Location.Y);
                gameExtras.addCardToList(TwelveCard, 11); //add object to a list of objects
                card12.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard ThirteenCard = new gameCard(card13, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -13, card13.Location.X, card13.Location.Y);
                gameExtras.addCardToList(ThirteenCard, 12); //add object to a list of objects
                card13.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard FourteenCard = new gameCard(card14, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -14, card14.Location.X, card14.Location.Y);
                gameExtras.addCardToList(FourteenCard, 13); //add object to a list of objects
                card14.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard FifteenCard = new gameCard(card15, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -15, card15.Location.X, card15.Location.Y);
                gameExtras.addCardToList(FifteenCard, 14); //add object to a list of objects
                card15.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard SixteenCard = new gameCard(card16, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -16, card16.Location.X, card16.Location.Y);
                gameExtras.addCardToList(SixteenCard, 15); //add object to a list of objects
                card16.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard SeventeenCard = new gameCard(card17, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -17, card17.Location.X, card17.Location.Y);
                gameExtras.addCardToList(SeventeenCard, 16); //add object to a list of objects
                card17.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard EighteenCard = new gameCard(card18, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -18, card18.Location.X, card18.Location.Y);
                gameExtras.addCardToList(EighteenCard, 17); //add object to a list of objects
                card18.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard NinteenCard = new gameCard(card19, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -19, card19.Location.X, card19.Location.Y);
                gameExtras.addCardToList(NinteenCard, 18); //add object to a list of objects
                card19.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameCard TwentyCard = new gameCard(card20, new Bitmap(@"..\..\Properties\playing_cards\cardBack.gif"), new Bitmap(@"..\..\Properties\playing_cards\66.jpg"), false, -20, card20.Location.X, card20.Location.Y);
                gameExtras.addCardToList(TwentyCard, 19); //add object to a list of objects
                card20.Enabled = true;
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                gameExtras.initializeArray();
                gameExtras.ImageRandomizer(); //randomly assign the unique image
                TempPc = null; //initialized
                countcardturned = 0; //initialized
                gpMenu.Enabled = false;
                gpMenu.Visible = false;

                //Set cards enabled to true

            }

            
        }


        int countcardturned = 0; //class scope
        SoundPlayer _booPL = new SoundPlayer(@"..\..\boo.wav");
        SoundPlayer _cheerPL = new SoundPlayer(@"..\..\cheer.wav");

        PictureBox TempPc = null;
        Timer time = new Timer();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void default_MouseClick(object sender, MouseEventArgs e){
            ///////////////////////////////////////////////
            time.Start();
            time.Enabled = true;
            //////////////////////////////////////////////
            
            //////////////////////////////////////////
            if (sender == card1 && e.Button == MouseButtons.Left)
            { //set the boolean, to stop the same card from...
                card1.Image = gameCard.returnUniqueCardImg(card1);
                AnimationClass.animateAnimateur(card1a);

                if (TempPc == card1)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card1;

                if (TempPc != null && TempPc != card1){
                    if (gameExtras.twoImgComparer(TempPc, card1) == true){
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card1) == true){
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null;
                    }

                    else{
                        //////////////////
                        countcardturned++;
                        /////////////////

                        TempPc.Refresh();
                        card1.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card1.Image = gameCard.returnCardImg(card1);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;

                    }
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card2 && e.Button == MouseButtons.Left){
                card2.Image = gameCard.returnUniqueCardImg(card2);///
                AnimationClass.animateAnimateur(card2a);

                if (TempPc == card2)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card2;

                if(TempPc != null && TempPc != card2){
                    if (gameExtras.twoImgComparer(TempPc, card2) == true){
                        //////////////////
                        countcardturned++;
                        /////////////////

                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card2) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else{
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card2.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card2.Image = gameCard.returnCardImg(card2);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            if (sender == card3 && e.Button == MouseButtons.Left)
            {
                card3.Image = gameCard.returnUniqueCardImg(card3);///
                AnimationClass.animateAnimateur(card3a);

                if (TempPc == card3)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card3;

                if (TempPc != null && TempPc != card3)
                {
                    if (gameExtras.twoImgComparer(TempPc, card3) == true)
                    {

                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card3) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null;
                    }
                    
                    else{
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card3.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card3.Image = gameCard.returnCardImg(card3);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card4 && e.Button == MouseButtons.Left)
            {
                card4.Image = gameCard.returnUniqueCardImg(card4);///
                AnimationClass.animateAnimateur(card4a);

                if (TempPc == card4)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card4;

                if (TempPc != null && TempPc != card4)
                {
                    if (gameExtras.twoImgComparer(TempPc, card4) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card4) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null;
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card4.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card4.Image = gameCard.returnCardImg(card4);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card5 && e.Button == MouseButtons.Left)
            {
                card5.Image = gameCard.returnUniqueCardImg(card5);///
                AnimationClass.animateAnimateur(card5a);

                if (TempPc == card5)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card5;

                if (TempPc != null && TempPc != card5)
                {
                    if (gameExtras.twoImgComparer(TempPc, card5) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card5) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null;
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card5.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card5.Image = gameCard.returnCardImg(card5);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card6 && e.Button == MouseButtons.Left)
            {
                card6.Image = gameCard.returnUniqueCardImg(card6);///
                AnimationClass.animateAnimateur(card6a);

                if (TempPc == card6)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card6;

                if (TempPc != null && TempPc != card6)
                {
                    if (gameExtras.twoImgComparer(TempPc, card6) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card6) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }

                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card6.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card6.Image = gameCard.returnCardImg(card6);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ///////////////////////////////////////////////////////////////////////
            if (sender == card7 && e.Button == MouseButtons.Left){
                card7.Image = gameCard.returnUniqueCardImg(card7);///
                AnimationClass.animateAnimateur(card7a);

                if (TempPc == card7)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card7;

                if (TempPc != null && TempPc != card7)
                {
                    if (gameExtras.twoImgComparer(TempPc, card7) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card7) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card7.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card7.Image = gameCard.returnCardImg(card7);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////////////     
            if (sender == card8 && e.Button == MouseButtons.Left)
            {
                card8.Image = gameCard.returnUniqueCardImg(card8);///
                AnimationClass.animateAnimateur(card8a);

                if (TempPc == card8)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card8;

                if (TempPc != null && TempPc != card8)
                {
                    if (gameExtras.twoImgComparer(TempPc, card8) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card8) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card8.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card8.Image = gameCard.returnCardImg(card8);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card9 && e.Button == MouseButtons.Left)
            {
                card9.Image = gameCard.returnUniqueCardImg(card9);///
                AnimationClass.animateAnimateur(card9a);

                if (TempPc == card9)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card9;

                if (TempPc != null && TempPc != card9)
                {
                    if (gameExtras.twoImgComparer(TempPc, card9) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card9) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card9.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card9.Image = gameCard.returnCardImg(card9);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card10 && e.Button == MouseButtons.Left)
            {
                card10.Image = gameCard.returnUniqueCardImg(card10);///
                AnimationClass.animateAnimateur(card10a);

                if (TempPc == card10)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card10;

                if (TempPc != null && TempPc != card10)
                {
                    if (gameExtras.twoImgComparer(TempPc, card10) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card10) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card10.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card10.Image = gameCard.returnCardImg(card10);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card11 && e.Button == MouseButtons.Left)
            {
                card11.Image = gameCard.returnUniqueCardImg(card11);///
                AnimationClass.animateAnimateur(card11a);

                if (TempPc == card11)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card11;

                if (TempPc != null && TempPc != card11)
                {
                    if (gameExtras.twoImgComparer(TempPc, card11) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card11) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card11.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card11.Image = gameCard.returnCardImg(card11);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card12 && e.Button == MouseButtons.Left)
            {
                card12.Image = gameCard.returnUniqueCardImg(card12);///
                AnimationClass.animateAnimateur(card12a);

                if (TempPc == card12)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card12;

                if (TempPc != null && TempPc != card12)
                {
                    if (gameExtras.twoImgComparer(TempPc, card12) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card12) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card12.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card12.Image = gameCard.returnCardImg(card12);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            /////////////////////////////////////////////////////////////////////
            if (sender == card13 && e.Button == MouseButtons.Left)
            {
                card13.Image = gameCard.returnUniqueCardImg(card13);///
                AnimationClass.animateAnimateur(card13a);

                if (TempPc == card13)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card13;

                if (TempPc != null && TempPc != card13)
                {
                    if (gameExtras.twoImgComparer(TempPc, card13) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card13) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card13.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card13.Image = gameCard.returnCardImg(card13);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            /////////////////////////////////////////////////////////////////////////////////
            if (sender == card14 && e.Button == MouseButtons.Left)
            {
                card14.Image = gameCard.returnUniqueCardImg(card14);///
                AnimationClass.animateAnimateur(card14a);

                if (TempPc == card14)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card14;

                if (TempPc != null && TempPc != card14)
                {
                    if (gameExtras.twoImgComparer(TempPc, card14) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card14) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card14.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card14.Image = gameCard.returnCardImg(card14);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            /////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card15 && e.Button == MouseButtons.Left)
            {
                card15.Image = gameCard.returnUniqueCardImg(card15);///
                AnimationClass.animateAnimateur(card15a);

                if (TempPc == card15)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card15;

                if (TempPc != null && TempPc != card15)
                {
                    if (gameExtras.twoImgComparer(TempPc, card15) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card15) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card15.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card15.Image = gameCard.returnCardImg(card15);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            /////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card16 && e.Button == MouseButtons.Left)
            {
                card16.Image = gameCard.returnUniqueCardImg(card16);///
                AnimationClass.animateAnimateur(card15a);

                if (TempPc == card16)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card16;

                if (TempPc != null && TempPc != card16)
                {
                    //////////////////
                    countcardturned++;
                    /////////////////
                    if (gameExtras.twoImgComparer(TempPc, card16) == true)
                    {
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card16) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card16.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card16.Image = gameCard.returnCardImg(card16);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            /////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card17 && e.Button == MouseButtons.Left)
            {
                card17.Image = gameCard.returnUniqueCardImg(card17);///
                AnimationClass.animateAnimateur(card17a);

                if (TempPc == card17)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card17;

                if (TempPc != null && TempPc != card17)
                {
                    if (gameExtras.twoImgComparer(TempPc, card17) == true)
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card17) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card17.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card17.Image = gameCard.returnCardImg(card17);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (sender == card18 && e.Button == MouseButtons.Left)
            {
                card18.Image = gameCard.returnUniqueCardImg(card18);///
                AnimationClass.animateAnimateur(card18a);

                if (TempPc == card18)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card18;

                if (TempPc != null && TempPc != card18)
                {
                    //////////////////
                    countcardturned++;
                    /////////////////
                    if (gameExtras.twoImgComparer(TempPc, card18) == true)
                    {
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card18) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card18.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card18.Image = gameCard.returnCardImg(card18);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }

            /////////////////////////////////////////////////////////////////////
            if (sender == card19 && e.Button == MouseButtons.Left)
            {
                card19.Image = gameCard.returnUniqueCardImg(card19);///
                AnimationClass.animateAnimateur(card19a);

                if (TempPc == card19)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card19;

                if (TempPc != null && TempPc != card19)
                {
                    //////////////////
                    countcardturned++;
                    /////////////////
                    if (gameExtras.twoImgComparer(TempPc, card19) == true)
                    {

                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card19) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card19.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card19.Image = gameCard.returnCardImg(card19);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
            ////////////////////////////////////////////////////////////////////////////////////
            if (sender == card20 && e.Button == MouseButtons.Left)
            {
                card20.Image = gameCard.returnUniqueCardImg(card20);///
                AnimationClass.animateAnimateur(card20a);

                if (TempPc == card20)
                    MessageBox.Show("Flip another card");

                if (TempPc == null)
                    TempPc = card20;

                if (TempPc != null && TempPc != card20)
                {
                    //////////////////
                    countcardturned++;
                    /////////////////
                    if (gameExtras.twoImgComparer(TempPc, card20) == true)
                    {
                        if (AnimationClass.animateCardRemoval(TempPc) == true || AnimationClass.animateCardRemoval(card20) == true)
                        {
                            gpMenu.Visible = true;
                            gpMenu.Enabled = true;
                            //////////////////////////////////////////////////////////////////////////////////////////////////////
                            if (countcardturned > 15)
                            {
                                try
                                {
                                    _cheerPL.Play();
                                }
                                catch (Exception problem2)
                                {
                                    MessageBox.Show("Cannot play the sound effect\n" + problem2.Message);
                                }
                            }
                        }
                        TempPc = null; //set for the next iterations
                    }

                    else
                    {
                        //////////////////
                        countcardturned++;
                        /////////////////
                        TempPc.Refresh();
                        card20.Refresh();
                        AnimationClass.animateWait();
                        TempPc.Image = gameCard.returnCardImg(TempPc);
                        card20.Image = gameCard.returnCardImg(card20);
                        //////////////////////////////////////////
                        if (TempPc != null)
                            TempPc = null;
                    }
                }
            }
        }

  
        /// <summary>
        /// Closes the game form
        /// </summary>
        /// <param name="sender">the control that generated the event</param>
        /// <param name="e">arguments about the event generated</param>
        private void btnExit_Click(object sender, EventArgs e){
            time.Stop();
            time.Enabled = false;
           
            AnimationClass.animateWait();

            DialogResult res = MessageBox.Show("Are you sure you want to quit?", "Exit", MessageBoxButtons.YesNoCancel);

            if(res == DialogResult.Yes)
                Application.Exit();
        }

        /// <summary>
        /// Restarts the game form
        /// </summary>
        /// <param name="sender">the control that generated the event</param>
        /// <param name="e">an argument about the event generated</param>
        private void button1_Click(object sender, EventArgs e){
            //Need to open the game form again
            frmGOM2.ActiveForm.Hide();
            Form newgameForm = new frmGOM2(true);

            newgameForm.ShowDialog(); //Add DialogResult
            this.Close();
            //
        }

        /// <summary>
        /// this method flips all the cards, showing their value to the user
        /// </summary>
        /// <param name="sender">the control that generated the event</param>
        /// <param name="e">an argument about the event generated</param>
        private void btnRetire_Click(object sender, EventArgs e){
            gameCard[] flipCards = gameExtras.returnListOfCards();

            if (sender == btnRetire)
            {
                foreach (gameCard g in flipCards)
                {
                    if (g.returnCardBoolean() == false)
                    {
                        //card1.Image = gameCard.returnUniqueCardImg(card1);
                        g.returnPictureBox().Image = gameCard.returnUniqueCardImg(g.returnPictureBox());
                        g.setCardBoolean(true);
                        g.returnPictureBox().Enabled = false;
                    }
                }
                AnimationClass.animateWait();
                gpMenu.Visible = true;
                gpMenu.Enabled = true;
                txtScore.Text = countcardturned.ToString();
            }
            //////////////////////////////////////////////////////////
            try{
                _booPL.Play();
            }
            
            catch (Exception problem1){
                MessageBox.Show("Cannot play the sound effect\n"+ problem1.Message);
            }
        }

        /// <summary>
        /// this method creates an animation
        /// </summary>
        /// <param name="sender">the control that generated the event</param>
        /// <param name="e">an argument about the event generated</param>
        private void frmGOM2_MouseMove(object sender, MouseEventArgs e){
            if (e.Location.X > 710 && e.Location.Y > 620){
                btnRetire.Visible = true;
                btnRetire.Enabled = true;
            }

            if (e.Location.X < 710 && e.Location.Y < 620)
            {
                btnRetire.Visible = false;
                btnRetire.Enabled = false;
            }
        }

        /// <summary>
        /// Retrieves the score of the game
        /// </summary>
        /// <param name="sender">the control that generated the event</param>
        /// <param name="e">the arguments about the events generated</param>
        private void gpMenu_VisibleChanged(object sender, EventArgs e){
            txtScore.Text = countcardturned.ToString();

           
        }

    }
}
