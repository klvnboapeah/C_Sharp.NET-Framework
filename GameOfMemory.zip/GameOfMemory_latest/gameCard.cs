﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**************************************
 * Kelvin Boapeah,
 * Dr. Kevin McDonnell,
 * Advanced Programming I,
 * December 17th 2013
 * **************************************/
namespace GameOfMemory
{
    class gameCard
    {

        //member variables
        PictureBox pcb;
        bool boolean;
        int Xloc, Yloc;
        int pictureindexer = -1;
        Image DefaultPic;
        Image unqImg;

        /// <summary>
        /// A no-argument constructor
        /// </summary>
        public gameCard() { }


        public gameCard(PictureBox PCB1, Image DefaultImg, Image uniqueImage, bool TF, int PicIndex, int XX, int YY)
        {
            pcb = PCB1;
            boolean = TF;
            pictureindexer = PicIndex;
            Xloc = XX;
            Yloc = YY;

            DefaultPic = DefaultImg;
            unqImg = uniqueImage;
            /////////////////
            pcb.Image = DefaultImg;
        }

        /// <summary>
        /// Set the code for the image.
        /// </summary>
        /// <param name="I">The image's code</param>
        public void setPicId(int I)
        {
            pictureindexer = I;
        }

        static int leaper = 0; //leap over the image that was read before
        /// <summary>
        /// Returns the code for the image, for this card
        /// </summary>
        /// <param name="s">The code for the image</param>
        /// <returns></returns>
        public static int getPicId(Image s)
        {
            gameCard[] gg = gameExtras.returnListOfCards();
            int tempInt = -1;

            for (int pp = 0; pp < gg.Length; pp++)
            {
                if ((pp - leaper) != 0 && gg[pp].returnUniqueCardImg() == s)
                {
                    tempInt = gg[pp].getPicId();
                    pp = gg.Length; //break out of the for-loop
                    leaper = pp;
                }
            }
            return tempInt;
        }

        /// <summary>
        /// using the specified picturebox given, this method goes through the list of cards, and searches for the card that has this picture-box
        /// </summary>
        /// <param name="pcb">the specified picture box</param>
        /// <returns>the object that has this picture box </returns>
        public static gameCard getObject(PictureBox pcb)
        {
            gameCard[] gg = gameExtras.returnListOfCards();
            gameCard temp = null; ////

            for (int pp = 0; pp < gg.Length; pp++)
            {
                if (gg[pp].returnPictureBox() == pcb)
                {
                    temp = gg[pp];
                }
            }
            return temp;
        }

        /// <summary>
        /// Returns the code for the image
        /// </summary>
        /// <returns>The code</returns>
        public int getPicId(){
            return pictureindexer;
        }

        /// <summary>
        /// Returns the picturebox of the specified card object
        /// </summary>
        /// <returns>the picturebox</returns>
        public PictureBox returnPictureBox()
        {
            return pcb;
        }

        /// <summary>
        ///  Returns the default image of the card. In other words the back of the card is displayed
        /// </summary>
        /// <returns>the back image</returns>
        public Image returnCardImg(){
            return DefaultPic;
        }

        /// <summary>
        /// Returns the default image of the card, given the picturebox of that card. In other words the back of the card is displayed
        /// </summary>
        /// <param name="pc">the specified picturebox of the card</param>
        /// <returns>the back image</returns>
        public static Image returnCardImg(PictureBox pc){
            gameCard[] gg = gameExtras.returnListOfCards();

            foreach (gameCard gcard in gg){
                if (gcard.returnPictureBox() == pc){
                    return gcard.returnCardImg();
                }
            }
            return null;
        }


        /// <summary>
        /// sets the back image of the card
        /// </summary>
        /// <param name="image">the back image given</param>
        public void setCardImg(Image image){
            DefaultPic = image;
        }

        /// <summary>
        /// returns the back image of the specified card object
        /// </summary>
        /// <returns>the back image</returns>
        public Image returnUniqueCardImg(){
            return unqImg;
        }

        /// <summary>
        /// returns the unique image of the card
        /// </summary>
        /// <param name="pc">the specified picturebox of the image</param>
        /// <returns>the unique image to be returned</returns>
        public static Image returnUniqueCardImg(PictureBox pc){

            gameCard[] gg = gameExtras.returnListOfCards();


            foreach (gameCard gcard in gg){
                if (gcard.returnPictureBox() == pc){
                    return gcard.returnUniqueCardImg();
                }
            }
            return null;
            }
            

        /// <summary>
        /// sets the unique image of the card
        /// </summary>
        /// <param name="img">the image that is specified</param>
        public void setUniqueCardImg(Image img)
        {
            unqImg = img;
        }

        /// <summary>
        /// Returns the x position of the card object
        /// </summary>
        /// <returns>X position</returns>
        public int returnX()
        {
            return Xloc;
        }


        /// <summary>
        /// returns the y position of the card object
        /// </summary>
        /// <returns>Y position</returns>
        public int returnY()
        {
            return Yloc;
        }

        /// <summary>
        /// given the picture box of a card object, this method returns the y-position of the card object on the table
        /// </summary>
        /// <param name="control">the picture box that is specified</param>
        /// <returns>the y position</returns>
        public int returnY(PictureBox control)
        {
            int Yloc = -1;
            gameCard[] gg = gameExtras.returnListOfCards();

            for (int p = 0; p < gg.Length; p++)
            {
                if (gg[p].returnPictureBox() == control)
                    Yloc = gg[p].returnY();
            }
            return Yloc;
        }

        /// <summary>
        /// Sets the x postion of the card boolean
        /// </summary>
        /// <param name="X"></param>
        public void setX(int X)
        {
            Xloc = X;
        }

        /// <summary>
        /// Sets the Y postion of the card object
        /// </summary>
        /// <param name="Y"></param>
        public void setY(int Y)
        {
            Yloc = Y;
        }

        /// <summary>
        /// Sets the X and Y position of the card of object
        /// </summary>
        /// <param name="X">The X position to be set</param>
        /// <param name="Y">The y postion to be set</param>
        public void setCoord(int X, int Y)
        {
            Xloc = X;
            Yloc = Y;
        }

        /// <summary>
        /// returns the card object's boolean value. True if the card is moved to the right, and false if the card is not moved
        /// </summary>
        /// <returns>the card's boolean value</returns>
        public bool returnCardBoolean()
        {
            return boolean;
        }

        /// <summary>
        /// Sets the card object's boolean value. True when the card is moved, and false if otherwise
        /// </summary>
        /// <param name="T">the boolean value to be set</param>
        public void setCardBoolean(bool T)
        {
            boolean = T;
        }
    }
       
}
