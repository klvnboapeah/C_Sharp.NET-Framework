﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameOfMemory
{
    public partial class frmFirstForm : Form
    {
        public frmFirstForm()
        {
            InitializeComponent();
        }

        private void TimerIntro_Tick(object sender, EventArgs e)
        {
            if(sender == TimerIntro)
            {
                TimerIntro.Stop();
                TimerIntro.Dispose(); //release all the resources used by the timer
                frmFirstForm.ActiveForm.Visible = false;
                Form newGoM = new frmGOM2(false);
                newGoM.ShowDialog(); //DialogResult = ....
            }
        }

    }
}
