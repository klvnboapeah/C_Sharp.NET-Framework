﻿namespace GameOfMemory
{
    partial class frmGOM2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGOM2));
            this.card1 = new System.Windows.Forms.PictureBox();
            this.card2 = new System.Windows.Forms.PictureBox();
            this.card3 = new System.Windows.Forms.PictureBox();
            this.card4 = new System.Windows.Forms.PictureBox();
            this.card5 = new System.Windows.Forms.PictureBox();
            this.card8 = new System.Windows.Forms.PictureBox();
            this.card14 = new System.Windows.Forms.PictureBox();
            this.card9 = new System.Windows.Forms.PictureBox();
            this.card15 = new System.Windows.Forms.PictureBox();
            this.card10 = new System.Windows.Forms.PictureBox();
            this.card18 = new System.Windows.Forms.PictureBox();
            this.card19 = new System.Windows.Forms.PictureBox();
            this.card20 = new System.Windows.Forms.PictureBox();
            this.card11 = new System.Windows.Forms.PictureBox();
            this.card12 = new System.Windows.Forms.PictureBox();
            this.card13 = new System.Windows.Forms.PictureBox();
            this.card6 = new System.Windows.Forms.PictureBox();
            this.card7 = new System.Windows.Forms.PictureBox();
            this.card16 = new System.Windows.Forms.PictureBox();
            this.card17 = new System.Windows.Forms.PictureBox();
            this.card6a = new System.Windows.Forms.PictureBox();
            this.card7a = new System.Windows.Forms.PictureBox();
            this.card8a = new System.Windows.Forms.PictureBox();
            this.card9a = new System.Windows.Forms.PictureBox();
            this.card10a = new System.Windows.Forms.PictureBox();
            this.card11a = new System.Windows.Forms.PictureBox();
            this.card12a = new System.Windows.Forms.PictureBox();
            this.card13a = new System.Windows.Forms.PictureBox();
            this.card14a = new System.Windows.Forms.PictureBox();
            this.card15a = new System.Windows.Forms.PictureBox();
            this.card16a = new System.Windows.Forms.PictureBox();
            this.card17a = new System.Windows.Forms.PictureBox();
            this.card18a = new System.Windows.Forms.PictureBox();
            this.card19a = new System.Windows.Forms.PictureBox();
            this.card20a = new System.Windows.Forms.PictureBox();
            this.card4a = new System.Windows.Forms.PictureBox();
            this.card3a = new System.Windows.Forms.PictureBox();
            this.card2a = new System.Windows.Forms.PictureBox();
            this.card1a = new System.Windows.Forms.PictureBox();
            this.card5a = new System.Windows.Forms.PictureBox();
            this.btnRetire = new System.Windows.Forms.Button();
            this.gpMenu = new System.Windows.Forms.GroupBox();
            this.txtScore = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblScore = new System.Windows.Forms.Label();
            this.btnRestart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.card1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5a)).BeginInit();
            this.gpMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // card1
            // 
            this.card1.BackColor = System.Drawing.Color.Maroon;
            this.card1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card1.Location = new System.Drawing.Point(0, 0);
            this.card1.Name = "card1";
            this.card1.Size = new System.Drawing.Size(136, 170);
            this.card1.TabIndex = 0;
            this.card1.TabStop = false;
            this.card1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card2
            // 
            this.card2.BackColor = System.Drawing.Color.Maroon;
            this.card2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card2.Location = new System.Drawing.Point(144, 0);
            this.card2.Name = "card2";
            this.card2.Size = new System.Drawing.Size(136, 170);
            this.card2.TabIndex = 1;
            this.card2.TabStop = false;
            this.card2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card3
            // 
            this.card3.BackColor = System.Drawing.Color.Maroon;
            this.card3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card3.Location = new System.Drawing.Point(288, 0);
            this.card3.Name = "card3";
            this.card3.Size = new System.Drawing.Size(136, 170);
            this.card3.TabIndex = 2;
            this.card3.TabStop = false;
            this.card3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card4
            // 
            this.card4.BackColor = System.Drawing.Color.Maroon;
            this.card4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card4.Location = new System.Drawing.Point(432, 0);
            this.card4.Name = "card4";
            this.card4.Size = new System.Drawing.Size(136, 170);
            this.card4.TabIndex = 3;
            this.card4.TabStop = false;
            this.card4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card5
            // 
            this.card5.BackColor = System.Drawing.Color.Maroon;
            this.card5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card5.Location = new System.Drawing.Point(576, 0);
            this.card5.Name = "card5";
            this.card5.Size = new System.Drawing.Size(136, 170);
            this.card5.TabIndex = 4;
            this.card5.TabStop = false;
            this.card5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card8
            // 
            this.card8.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.card8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card8.Location = new System.Drawing.Point(288, 176);
            this.card8.Name = "card8";
            this.card8.Size = new System.Drawing.Size(136, 170);
            this.card8.TabIndex = 5;
            this.card8.TabStop = false;
            this.card8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card14
            // 
            this.card14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.card14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card14.Location = new System.Drawing.Point(432, 352);
            this.card14.Name = "card14";
            this.card14.Size = new System.Drawing.Size(136, 170);
            this.card14.TabIndex = 6;
            this.card14.TabStop = false;
            this.card14.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card9
            // 
            this.card9.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.card9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card9.Location = new System.Drawing.Point(432, 176);
            this.card9.Name = "card9";
            this.card9.Size = new System.Drawing.Size(136, 170);
            this.card9.TabIndex = 7;
            this.card9.TabStop = false;
            this.card9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card15
            // 
            this.card15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.card15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card15.Location = new System.Drawing.Point(576, 352);
            this.card15.Name = "card15";
            this.card15.Size = new System.Drawing.Size(136, 170);
            this.card15.TabIndex = 8;
            this.card15.TabStop = false;
            this.card15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card10
            // 
            this.card10.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.card10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card10.Location = new System.Drawing.Point(576, 176);
            this.card10.Name = "card10";
            this.card10.Size = new System.Drawing.Size(136, 170);
            this.card10.TabIndex = 9;
            this.card10.TabStop = false;
            this.card10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card18
            // 
            this.card18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.card18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card18.Location = new System.Drawing.Point(288, 528);
            this.card18.Name = "card18";
            this.card18.Size = new System.Drawing.Size(136, 170);
            this.card18.TabIndex = 10;
            this.card18.TabStop = false;
            this.card18.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card19
            // 
            this.card19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.card19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card19.Location = new System.Drawing.Point(432, 528);
            this.card19.Name = "card19";
            this.card19.Size = new System.Drawing.Size(136, 170);
            this.card19.TabIndex = 11;
            this.card19.TabStop = false;
            this.card19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card20
            // 
            this.card20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.card20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card20.Location = new System.Drawing.Point(576, 528);
            this.card20.Name = "card20";
            this.card20.Size = new System.Drawing.Size(136, 170);
            this.card20.TabIndex = 12;
            this.card20.TabStop = false;
            this.card20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card11
            // 
            this.card11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.card11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card11.Location = new System.Drawing.Point(0, 352);
            this.card11.Name = "card11";
            this.card11.Size = new System.Drawing.Size(136, 170);
            this.card11.TabIndex = 13;
            this.card11.TabStop = false;
            this.card11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card12
            // 
            this.card12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.card12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card12.Location = new System.Drawing.Point(144, 352);
            this.card12.Name = "card12";
            this.card12.Size = new System.Drawing.Size(136, 170);
            this.card12.TabIndex = 14;
            this.card12.TabStop = false;
            this.card12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card13
            // 
            this.card13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.card13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card13.Location = new System.Drawing.Point(288, 352);
            this.card13.Name = "card13";
            this.card13.Size = new System.Drawing.Size(136, 170);
            this.card13.TabIndex = 15;
            this.card13.TabStop = false;
            this.card13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card6
            // 
            this.card6.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.card6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card6.Location = new System.Drawing.Point(0, 176);
            this.card6.Name = "card6";
            this.card6.Size = new System.Drawing.Size(136, 170);
            this.card6.TabIndex = 16;
            this.card6.TabStop = false;
            this.card6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card7
            // 
            this.card7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.card7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card7.Location = new System.Drawing.Point(144, 176);
            this.card7.Name = "card7";
            this.card7.Size = new System.Drawing.Size(136, 170);
            this.card7.TabIndex = 17;
            this.card7.TabStop = false;
            this.card7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card16
            // 
            this.card16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.card16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card16.Location = new System.Drawing.Point(0, 528);
            this.card16.Name = "card16";
            this.card16.Size = new System.Drawing.Size(136, 170);
            this.card16.TabIndex = 18;
            this.card16.TabStop = false;
            this.card16.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card17
            // 
            this.card17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.card17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.card17.Location = new System.Drawing.Point(144, 528);
            this.card17.Name = "card17";
            this.card17.Size = new System.Drawing.Size(136, 170);
            this.card17.TabIndex = 19;
            this.card17.TabStop = false;
            this.card17.MouseDown += new System.Windows.Forms.MouseEventHandler(this.default_MouseClick);
            // 
            // card6a
            // 
            this.card6a.BackColor = System.Drawing.Color.DarkTurquoise;
            this.card6a.Location = new System.Drawing.Point(0, 704);
            this.card6a.Name = "card6a";
            this.card6a.Size = new System.Drawing.Size(35, 12);
            this.card6a.TabIndex = 20;
            this.card6a.TabStop = false;
            // 
            // card7a
            // 
            this.card7a.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.card7a.Location = new System.Drawing.Point(0, 704);
            this.card7a.Name = "card7a";
            this.card7a.Size = new System.Drawing.Size(35, 12);
            this.card7a.TabIndex = 21;
            this.card7a.TabStop = false;
            // 
            // card8a
            // 
            this.card8a.BackColor = System.Drawing.Color.LightCyan;
            this.card8a.Location = new System.Drawing.Point(0, 704);
            this.card8a.Name = "card8a";
            this.card8a.Size = new System.Drawing.Size(35, 12);
            this.card8a.TabIndex = 22;
            this.card8a.TabStop = false;
            // 
            // card9a
            // 
            this.card9a.BackColor = System.Drawing.Color.Aqua;
            this.card9a.Location = new System.Drawing.Point(0, 704);
            this.card9a.Name = "card9a";
            this.card9a.Size = new System.Drawing.Size(35, 12);
            this.card9a.TabIndex = 23;
            this.card9a.TabStop = false;
            // 
            // card10a
            // 
            this.card10a.BackColor = System.Drawing.Color.Honeydew;
            this.card10a.Location = new System.Drawing.Point(0, 704);
            this.card10a.Name = "card10a";
            this.card10a.Size = new System.Drawing.Size(35, 12);
            this.card10a.TabIndex = 24;
            this.card10a.TabStop = false;
            // 
            // card11a
            // 
            this.card11a.BackColor = System.Drawing.Color.Lime;
            this.card11a.Location = new System.Drawing.Point(0, 704);
            this.card11a.Name = "card11a";
            this.card11a.Size = new System.Drawing.Size(35, 12);
            this.card11a.TabIndex = 25;
            this.card11a.TabStop = false;
            // 
            // card12a
            // 
            this.card12a.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.card12a.Location = new System.Drawing.Point(0, 704);
            this.card12a.Name = "card12a";
            this.card12a.Size = new System.Drawing.Size(35, 12);
            this.card12a.TabIndex = 26;
            this.card12a.TabStop = false;
            // 
            // card13a
            // 
            this.card13a.BackColor = System.Drawing.Color.Chartreuse;
            this.card13a.Location = new System.Drawing.Point(0, 704);
            this.card13a.Name = "card13a";
            this.card13a.Size = new System.Drawing.Size(35, 12);
            this.card13a.TabIndex = 27;
            this.card13a.TabStop = false;
            // 
            // card14a
            // 
            this.card14a.BackColor = System.Drawing.Color.Ivory;
            this.card14a.Location = new System.Drawing.Point(0, 704);
            this.card14a.Name = "card14a";
            this.card14a.Size = new System.Drawing.Size(35, 12);
            this.card14a.TabIndex = 28;
            this.card14a.TabStop = false;
            // 
            // card15a
            // 
            this.card15a.BackColor = System.Drawing.Color.Yellow;
            this.card15a.Location = new System.Drawing.Point(0, 704);
            this.card15a.Name = "card15a";
            this.card15a.Size = new System.Drawing.Size(35, 12);
            this.card15a.TabIndex = 29;
            this.card15a.TabStop = false;
            // 
            // card16a
            // 
            this.card16a.BackColor = System.Drawing.Color.GreenYellow;
            this.card16a.Location = new System.Drawing.Point(0, 704);
            this.card16a.Name = "card16a";
            this.card16a.Size = new System.Drawing.Size(35, 12);
            this.card16a.TabIndex = 30;
            this.card16a.TabStop = false;
            // 
            // card17a
            // 
            this.card17a.BackColor = System.Drawing.Color.DarkRed;
            this.card17a.Location = new System.Drawing.Point(0, 704);
            this.card17a.Name = "card17a";
            this.card17a.Size = new System.Drawing.Size(35, 12);
            this.card17a.TabIndex = 31;
            this.card17a.TabStop = false;
            // 
            // card18a
            // 
            this.card18a.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.card18a.Location = new System.Drawing.Point(0, 704);
            this.card18a.Name = "card18a";
            this.card18a.Size = new System.Drawing.Size(35, 12);
            this.card18a.TabIndex = 32;
            this.card18a.TabStop = false;
            // 
            // card19a
            // 
            this.card19a.BackColor = System.Drawing.SystemColors.Highlight;
            this.card19a.Location = new System.Drawing.Point(0, 704);
            this.card19a.Name = "card19a";
            this.card19a.Size = new System.Drawing.Size(35, 12);
            this.card19a.TabIndex = 33;
            this.card19a.TabStop = false;
            // 
            // card20a
            // 
            this.card20a.BackColor = System.Drawing.SystemColors.ControlLight;
            this.card20a.Location = new System.Drawing.Point(0, 704);
            this.card20a.Name = "card20a";
            this.card20a.Size = new System.Drawing.Size(35, 12);
            this.card20a.TabIndex = 34;
            this.card20a.TabStop = false;
            // 
            // card4a
            // 
            this.card4a.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.card4a.Location = new System.Drawing.Point(0, 704);
            this.card4a.Name = "card4a";
            this.card4a.Size = new System.Drawing.Size(35, 12);
            this.card4a.TabIndex = 35;
            this.card4a.TabStop = false;
            // 
            // card3a
            // 
            this.card3a.BackColor = System.Drawing.Color.BlueViolet;
            this.card3a.Location = new System.Drawing.Point(0, 704);
            this.card3a.Name = "card3a";
            this.card3a.Size = new System.Drawing.Size(35, 12);
            this.card3a.TabIndex = 36;
            this.card3a.TabStop = false;
            // 
            // card2a
            // 
            this.card2a.BackColor = System.Drawing.Color.Blue;
            this.card2a.Location = new System.Drawing.Point(0, 704);
            this.card2a.Name = "card2a";
            this.card2a.Size = new System.Drawing.Size(35, 12);
            this.card2a.TabIndex = 37;
            this.card2a.TabStop = false;
            // 
            // card1a
            // 
            this.card1a.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.card1a.Location = new System.Drawing.Point(0, 704);
            this.card1a.Name = "card1a";
            this.card1a.Size = new System.Drawing.Size(35, 12);
            this.card1a.TabIndex = 38;
            this.card1a.TabStop = false;
            // 
            // card5a
            // 
            this.card5a.BackColor = System.Drawing.Color.Fuchsia;
            this.card5a.Location = new System.Drawing.Point(0, 704);
            this.card5a.Name = "card5a";
            this.card5a.Size = new System.Drawing.Size(35, 12);
            this.card5a.TabIndex = 39;
            this.card5a.TabStop = false;
            // 
            // btnRetire
            // 
            this.btnRetire.BackColor = System.Drawing.Color.Black;
            this.btnRetire.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRetire.Enabled = false;
            this.btnRetire.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRetire.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetire.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRetire.Location = new System.Drawing.Point(718, 629);
            this.btnRetire.Name = "btnRetire";
            this.btnRetire.Size = new System.Drawing.Size(195, 69);
            this.btnRetire.TabIndex = 2;
            this.btnRetire.Text = "&Retire";
            this.btnRetire.UseVisualStyleBackColor = false;
            this.btnRetire.Visible = false;
            this.btnRetire.Click += new System.EventHandler(this.btnRetire_Click);
            // 
            // gpMenu
            // 
            this.gpMenu.BackColor = System.Drawing.Color.Transparent;
            this.gpMenu.Controls.Add(this.txtScore);
            this.gpMenu.Controls.Add(this.btnExit);
            this.gpMenu.Controls.Add(this.lblScore);
            this.gpMenu.Controls.Add(this.btnRestart);
            this.gpMenu.Enabled = false;
            this.gpMenu.Location = new System.Drawing.Point(24, 216);
            this.gpMenu.Name = "gpMenu";
            this.gpMenu.Size = new System.Drawing.Size(1006, 242);
            this.gpMenu.TabIndex = 41;
            this.gpMenu.TabStop = false;
            this.gpMenu.Visible = false;
            this.gpMenu.VisibleChanged += new System.EventHandler(this.gpMenu_VisibleChanged);
            // 
            // txtScore
            // 
            this.txtScore.BackColor = System.Drawing.Color.Black;
            this.txtScore.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtScore.ForeColor = System.Drawing.Color.White;
            this.txtScore.Location = new System.Drawing.Point(358, 96);
            this.txtScore.Name = "txtScore";
            this.txtScore.ReadOnly = true;
            this.txtScore.Size = new System.Drawing.Size(244, 73);
            this.txtScore.TabIndex = 44;
            this.txtScore.TabStop = false;
            this.txtScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnExit
            // 
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnExit.Location = new System.Drawing.Point(832, 96);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(130, 75);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.SystemColors.Control;
            this.lblScore.Location = new System.Drawing.Point(68, 96);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(284, 73);
            this.lblScore.TabIndex = 43;
            this.lblScore.Text = "SCORE:";
            // 
            // btnRestart
            // 
            this.btnRestart.BackColor = System.Drawing.Color.Transparent;
            this.btnRestart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRestart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRestart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRestart.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRestart.Location = new System.Drawing.Point(683, 96);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(130, 75);
            this.btnRestart.TabIndex = 0;
            this.btnRestart.Text = "Rest&art";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmGOM2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1030, 718);
            this.Controls.Add(this.gpMenu);
            this.Controls.Add(this.btnRetire);
            this.Controls.Add(this.card5a);
            this.Controls.Add(this.card1a);
            this.Controls.Add(this.card2a);
            this.Controls.Add(this.card3a);
            this.Controls.Add(this.card4a);
            this.Controls.Add(this.card20a);
            this.Controls.Add(this.card19a);
            this.Controls.Add(this.card18a);
            this.Controls.Add(this.card17a);
            this.Controls.Add(this.card16a);
            this.Controls.Add(this.card15a);
            this.Controls.Add(this.card14a);
            this.Controls.Add(this.card13a);
            this.Controls.Add(this.card12a);
            this.Controls.Add(this.card11a);
            this.Controls.Add(this.card10a);
            this.Controls.Add(this.card9a);
            this.Controls.Add(this.card8a);
            this.Controls.Add(this.card7a);
            this.Controls.Add(this.card6a);
            this.Controls.Add(this.card17);
            this.Controls.Add(this.card16);
            this.Controls.Add(this.card7);
            this.Controls.Add(this.card6);
            this.Controls.Add(this.card13);
            this.Controls.Add(this.card12);
            this.Controls.Add(this.card11);
            this.Controls.Add(this.card20);
            this.Controls.Add(this.card19);
            this.Controls.Add(this.card18);
            this.Controls.Add(this.card10);
            this.Controls.Add(this.card15);
            this.Controls.Add(this.card9);
            this.Controls.Add(this.card14);
            this.Controls.Add(this.card8);
            this.Controls.Add(this.card5);
            this.Controls.Add(this.card4);
            this.Controls.Add(this.card3);
            this.Controls.Add(this.card2);
            this.Controls.Add(this.card1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmGOM2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game Of Memory";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmGOM2_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.card1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5a)).EndInit();
            this.gpMenu.ResumeLayout(false);
            this.gpMenu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox card1;
        private System.Windows.Forms.PictureBox card2;
        private System.Windows.Forms.PictureBox card3;
        private System.Windows.Forms.PictureBox card4;
        private System.Windows.Forms.PictureBox card5;
        private System.Windows.Forms.PictureBox card8;
        private System.Windows.Forms.PictureBox card14;
        private System.Windows.Forms.PictureBox card9;
        private System.Windows.Forms.PictureBox card15;
        private System.Windows.Forms.PictureBox card10;
        private System.Windows.Forms.PictureBox card18;
        private System.Windows.Forms.PictureBox card19;
        private System.Windows.Forms.PictureBox card20;
        private System.Windows.Forms.PictureBox card11;
        private System.Windows.Forms.PictureBox card12;
        private System.Windows.Forms.PictureBox card13;
        private System.Windows.Forms.PictureBox card6;
        private System.Windows.Forms.PictureBox card7;
        private System.Windows.Forms.PictureBox card16;
        private System.Windows.Forms.PictureBox card17;
        private System.Windows.Forms.PictureBox card6a;
        private System.Windows.Forms.PictureBox card7a;
        private System.Windows.Forms.PictureBox card8a;
        private System.Windows.Forms.PictureBox card9a;
        private System.Windows.Forms.PictureBox card10a;
        private System.Windows.Forms.PictureBox card11a;
        private System.Windows.Forms.PictureBox card12a;
        private System.Windows.Forms.PictureBox card13a;
        private System.Windows.Forms.PictureBox card14a;
        private System.Windows.Forms.PictureBox card15a;
        private System.Windows.Forms.PictureBox card16a;
        private System.Windows.Forms.PictureBox card17a;
        private System.Windows.Forms.PictureBox card18a;
        private System.Windows.Forms.PictureBox card19a;
        private System.Windows.Forms.PictureBox card20a;
        private System.Windows.Forms.PictureBox card4a;
        private System.Windows.Forms.PictureBox card3a;
        private System.Windows.Forms.PictureBox card2a;
        private System.Windows.Forms.PictureBox card1a;
        private System.Windows.Forms.PictureBox card5a;
        private System.Windows.Forms.Button btnRetire;
        private System.Windows.Forms.GroupBox gpMenu;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.TextBox txtScore;
    }
}