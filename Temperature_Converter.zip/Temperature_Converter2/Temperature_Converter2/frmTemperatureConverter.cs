﻿/**********************************************************************************
 * Kevin Boapeah,
 * Instructor: Dr. Kevin McDonnell,
 * Course: Advanced programming,
 * Date: September 26th, 2013.
 * 
 * Note- When the user enters a value in two or more fields, the calculation is done for the first entry value
 * *******************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// This is the coding for the form "frmTemperatureConverter"
namespace Temperature_Converter2
{
    public partial class frmTemperatureConverter : Form
    {
        public frmTemperatureConverter()
        {
            InitializeComponent();
        }

        bool tf = false;

        /// <summary>
        /// This method closes the form when the user clicks the Exit button
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">contains information about the object and event</param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// This method does the temperature conversion when the calculate button is clicked by the user
        /// </summary>
        /// <param name="sender">the object that's generated the event</param>
        /// <param name="e">contains information about the object and event</param>
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            //try-catch statement or exception handler
            try
            {
                if (isValidata()) // data validation
                {
                    decimal cel, kel, fah, ran, re;
                    ////Calculations//////20 different equations///////
                    if(txtCelsius.Text != "") //FROM celsius to other values
                    {
                        cel = Decimal.Parse(txtCelsius.Text);
                        txtKelvin.Text = Math.Round((cel + (decimal)273.15), 2).ToString(); //widening conversion
                        txtFahrenheit.Text = Math.Round((cel * (decimal)(9.0/5.0) + 32), 2).ToString();
                        txtRankine.Text = Math.Round((cel + (decimal)273.15) * (decimal)(9.0 / 5.0), 2).ToString();
                        txtReaumur.Text = Math.Round((cel * (decimal)(4.0 / 5.0)), 2).ToString();
                        tf = true;
                    }

                    if(txtKelvin.Text != "") // From kelvin to other values
                    {
                        kel = Decimal.Parse(txtKelvin.Text);
                        txtCelsius.Text = Math.Round((kel - (decimal)273.15), 2).ToString(); //widening conversion
                        txtFahrenheit.Text = Math.Round((kel * (decimal)(9.0 / 5.0) - (decimal)459.67), 2).ToString();
                        txtRankine.Text = Math.Round((kel * (decimal)(9.0 / 5.0)), 2).ToString();
                        txtReaumur.Text = Math.Round((kel - (decimal)273.15) * (decimal)(4.0 / 5.0), 2).ToString();
                        tf = true;
                    }

                    if(txtFahrenheit.Text != "") // From fahrenheit to other values
                    {
                        fah = Decimal.Parse(txtFahrenheit.Text);
                        txtCelsius.Text = Math.Round((fah - (decimal)32) * (decimal)(5.0 / 9.0), 2).ToString();
                        txtKelvin.Text = Math.Round((fah + (decimal)459.67) * (decimal)(5.0 / 9.0), 2).ToString();
                        txtRankine.Text = Math.Round((fah + (decimal)(459.67)), 2).ToString();
                        txtReaumur.Text = Math.Round((fah - (decimal)32) * (decimal)(4.0 / 9.0), 2).ToString();
                        tf = true;
                    }

                    if(txtRankine.Text != "") //From rankine to other values
                    {
                        ran = Decimal.Parse(txtRankine.Text);
                        txtFahrenheit.Text = Math.Round((ran - (decimal)459.67), 2).ToString();
                        txtCelsius.Text = Math.Round((ran - (decimal)491.67) * (decimal)(5.0 / 9.0), 2).ToString();
                        txtKelvin.Text = Math.Round(ran * (decimal)(5.0 / 9.0), 2).ToString();
                        txtReaumur.Text = Math.Round((ran - (decimal)491.67) * (decimal)(4.0 / 9.0), 2).ToString();
                        tf = true;
                    }

                    if(txtReaumur.Text != "") //From reaumur to other values
                    {
                        re = Decimal.Parse(txtReaumur.Text);
                        txtFahrenheit.Text = Math.Round((re * (decimal)(9.0 / 4.0)) + (decimal)32, 2).ToString();
                        txtKelvin.Text = Math.Round((re * (decimal)(5.0 / 4.0)) + (decimal)273.15, 2).ToString();
                        txtCelsius.Text = Math.Round((re * (decimal)(5.0 / 4.0)), 2).ToString();
                        txtRankine.Text = Math.Round((re * (decimal)(9.0 / 4.0)) + (decimal)491.67, 2).ToString();
                        tf = true;
                    }
                }
            }
                //catch clause
            catch (Exception ex) //throws a general exception called "ex". Also prints out a message about the exception, the type, and the stack of methods called prior to 
            {
                                    // the exception occurring
            
                MessageBox.Show(ex.Message + "\n\n" +
                    ex.GetType().ToString() + "\n" +
                    ex.StackTrace, "Exception");
            }

            finally // when an exception is thrown, the program still sets the flag variable to true, ready for the next calculation
            {
                tf = true;
            }
        }


        /// <summary>
        /// This method returns true if all the data are entered correctly, false if otherwise
        /// </summary>
        /// <returns>true, if data is entered correctly, and false, if otherwise</returns>
        public bool isValidata()
        {
            
           
            while (IsPresent(txtFahrenheit, "Fahrenheit") == false && IsPresent(txtCelsius, "Celsius") == false &&
                 IsPresent(txtKelvin, "Kelvin") == false && IsPresent(txtRankine, "Rankine") == false && IsPresent(txtReaumur, "Reaumur") == false)
                 {
                     MessageBox.Show("Enter a value into any one of the fields", "Entry Error");
                     return false;
                 }

            if (IsDecimal(txtFahrenheit, "Fahrenheit") == false && IsDecimal(txtCelsius, "Celsius") == false &&
                IsDecimal(txtKelvin, "Kelvin") == false && IsDecimal(txtRankine, "Rankine") == false && IsDecimal(txtReaumur, "Reaumur") == false)
            {
                MessageBox.Show("Entry must be a decimal value.", "Entry Error");

            }
            return true;
        }

        /// <summary>
        /// This method check whether an entry has been entered into the textbox. It displays an error message 
        /// if the textbox is empty
        /// </summary>
        /// <param name="textBox">The field containing the users entry</param>
        /// <param name="name">the name of the entry field</param>
        /// <returns>true if there is a user entry, and false if otherwise</returns>
        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == "")
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// This method converts the users entry into a decimal
        /// </summary>
        /// <param name="textBox">the field containing the users entry</param>
        /// <param name="name">the name of the entry field</param>
        /// <returns>true if the conversion is successful, and false if otherwise</returns>
        public bool IsDecimal (TextBox textBox, string name)
        {
            decimal number = 0m;
            if (Decimal.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// This method sets the other fields empty when the entry in txtFahrenheit field is cleared by the user
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">contains informaton about the event</param>
        private void txtFahrenheit_TextChanged(object sender, EventArgs e)
        {
            // issue doesnt work for single numbers
            if (txtFahrenheit.Text == "") //WORKS. sets every field empty when the input is deleted
            {
                txtKelvin.Text = "";
                txtCelsius.Text = "";
                txtRankine.Text = "";
                txtReaumur.Text = "";
                //////////////////////
            }
        }

        /// <summary>
        /// This method sets the other fields empty when the entry in txtCelsius field is cleared by the user
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">contains information about the event</param>
        private void txtCelsius_TextChanged(object sender, EventArgs e)
        {
            // issue doesnt work for single numbers
            if (txtCelsius.Text == "") //WORKS. sets every field empty when the input is deleted
            {
                txtFahrenheit.Text = "";
                txtKelvin.Text = "";
                txtRankine.Text = "";
                txtReaumur.Text = "";
                //////////////////////
            }
        }

        /// <summary>
        /// This method sets the other fields empty when the entry in txtKelvin field is cleared by the user
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">containes information about the event</param>
        private void txtKelvin_TextChanged(object sender, EventArgs e)
        {
            // issue doesnt work for single numbers
            if (txtKelvin.Text == "") //WORKS. sets every field empty when the input is deleted
            {
                txtFahrenheit.Text = "";
                txtCelsius.Text = "";
                txtRankine.Text = "";
                txtReaumur.Text = "";
                //////////////////////
            }
        }

        /// <summary>
        /// This method sets the other fields empty when the entry in txtRankine field is cleared by the user
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">containes information about the event</param>
        private void txtRankine_TextChanged(object sender, EventArgs e)
        {
            // issue doesnt work for single numbers
            if (txtRankine.Text == "") //WORKS. sets every field empty when the input is deleted
            {
                txtFahrenheit.Text = "";
                txtCelsius.Text = "";
                txtKelvin.Text = "";
                txtReaumur.Text = "";
                //////////////////////
            }
        }

        /// <summary>
        /// This method sets the other fields empty when the entry in txtReaumur field is cleared by the user
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">containes information about the event</param>
        private void txtReaumur_TextChanged(object sender, EventArgs e)
        {
            // issue doesnt work for single numbers
            if (txtReaumur.Text == "") //WORKS. sets every field empty when the input is deleted
            {
                txtFahrenheit.Text = "";
                txtCelsius.Text = "";
                txtRankine.Text = "";
                txtKelvin.Text = "";
                /////////////////////
            }
        }
        
        /// <summary>
        /// This method clears the field entry from the previous calculation, when any key is pressed. It uses a flag variable
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">contains information about the event</param>
        private void txtFahrenheit_KeyDown(object sender, KeyEventArgs e)
        {
            if (tf == true)
            {
                txtReaumur.Text = "";
                txtFahrenheit.Text = "";
                txtCelsius.Text = "";
                txtRankine.Text = "";
                txtKelvin.Text = "";
                tf = false;
            }
        }

        /// <summary>
        /// This method clears the field entry from the previous calculation, when any key is pressed. It uses a flag variable to check whether a calculated was done
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">contains information about the event</param>
        private void txtCelsius_KeyDown(object sender, KeyEventArgs e)
        {
            if (tf == true)
            {
                txtReaumur.Text = "";
                txtFahrenheit.Text = "";
                txtCelsius.Text = "";
                txtRankine.Text = "";
                txtKelvin.Text = "";
                tf = false;
            }
        }

        /// <summary>
        /// This method clears the field entry from the previous calculation, when any key is pressed. It uses a flag variable to check whether a calculated was done 
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">contains information about the event</param>
        private void txtKelvin_KeyDown(object sender, KeyEventArgs e)
        {
            if (tf == true)
            {
                txtReaumur.Text = "";
                txtFahrenheit.Text = "";
                txtCelsius.Text = "";
                txtRankine.Text = "";
                txtKelvin.Text = "";
                tf = false;
            }
        }
        
        /// <summary>
        /// This method clears the field entry from the previous calculation, when any key is pressed. It uses a flag variable to check whether a calculated was done
        /// </summary>
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">contains information about the event</param>
        private void txtRankine_KeyDown(object sender, KeyEventArgs e)
        {
            if (tf == true)
            {
                txtReaumur.Text = "";
                txtFahrenheit.Text = "";
                txtCelsius.Text = "";
                txtRankine.Text = "";
                txtKelvin.Text = "";
                tf = false;
            }
        }

        /// <summary>
        /// This method clears the field entry from the previous calculation, when any key is pressed. It uses a flag variable to check whether a calculated was done
        /// <param name="sender">the object that generated the event</param>
        /// <param name="e">contains information about the event</param>
        private void txtReaumur_KeyDown(object sender, KeyEventArgs e)
        {
            if (tf == true)
            {
                txtReaumur.Text = "";
                txtFahrenheit.Text = "";
                txtCelsius.Text = "";
                txtRankine.Text = "";
                txtKelvin.Text = "";
                tf = false;
            }
        }
    }
}

